const mongoose = require("mongoose");

const todoShcema = new mongoose.Schema({
  userId: String,
  title: String,
  desc: String,
  complete: {
    type: Boolean,
    default: false,
  },
  datetime: Date,
});

module.exports = mongoose.model("mytodo", todoShcema);
