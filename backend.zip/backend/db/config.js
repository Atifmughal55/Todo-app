const mongoose = require("mongoose");
const dotenv = require("dotenv").config();

const dbConnection = async () => {
  try {
    let conn = await mongoose.connect(process.env.DB_URL);
    console.log(`Database is connected to ${conn.connection.host}`);
  } catch (err) {
    console.log("Error in connection", err);
  }
};
module.exports = dbConnection;
