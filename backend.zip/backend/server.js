const express = require("express");
const app = express();
const dotenv = require("dotenv");
const dbConnection = require("./db/config");
const User = require("./db/newUser");
const Todo = require("./db/todo");
const cors = require("cors");

app.use(express.json());
dbConnection();
dotenv.config();
app.use(cors());

// Hit new User record to the database.
app.post("/register", async (req, res) => {
  let user = new User(req.body);
  let result = await user.save();
  res.send(result);
});

// Hit TODO data to the mongo database.
app.post("/todo", async (req, res) => {
  let todo = new Todo(req.body);
  let result = await todo.save();
  res.send(result);
});

//Get Todo data from the database.
app.get("/todouncomplete/:id", async (req, res) => {
  let todo = await Todo.find({ userId: req.params.id, complete: false });
  res.send(todo);

  // if (todo.length > 0) {
  // } else {
  //   res.send("No single Record found");
  // }
});

app.put("/recycle/:id", async (req, res) => {
  let todo = await Todo.updateOne(
    { _id: req.params.id },
    { $set: { complete: false } }
  );
  res.send(todo);
});

app.get("/todocomplete/:id", async (req, res) => {
  let todo = await Todo.find({
    userId: req.params.id,
    complete: true,
  });
  res.send(todo);

  // if (todo.length > 0) {
  // } else {
  //   res.send("No single Record found");
  // }
});
//Delete the Todo from database.
app.delete("/todo/:id", async (req, res) => {
  let deleteTodo = await Todo.deleteOne({ _id: req.params.id });
  res.send(deleteTodo);
});

//Edit the list of tasks in the database
app.get("/todo/:id", async (req, res) => {
  let todoGet = await Todo.findOne({ _id: req.params.id });

  res.send(todoGet);
});

app.put("/todo/:id", async (req, res) => {
  let result = await Todo.updateOne({ _id: req.params.id }, { $set: req.body });
  res.send(result);
});

app.put("/todo/complete/:id", async (req, res) => {
  let result = await Todo.updateOne(
    { _id: req.params.id },
    { $set: { complete: true, datetime: new Date() } }
  );
  res.send(result);
});

//compare LOGIN data to the SIGNUP data.
app.get("/register/:username", async (req, res) => {
  let getUser = await User.findOne({ username: req.params.username });
  // console.log(getUser);
  if (getUser) {
    res.send(getUser);
  } else {
    res.send({ error: "Record not found" });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running ${PORT}`);
});
