import React from "react";
import { Outlet } from "react-router";

const Footer = () => {
  return (
    <div>
      {/* <!-- Remove the container if you want to extend the Footer to full width. --> */}
      {/* <div className="container my-5"> */}
      <section className="">
        <footer
          className="text-center text-white"
          style={{
            backgroundColor: "#0a4275",
            width: "100%",
            // marginTop: "5px",
          }}
        >
          <div className="container p-4 pb-0">
            <section className="">
              <p className="d-flex justify-content-center align-items-center">
                <span className="me-3">Register for free</span>
              </p>
            </section>
          </div>

          <div
            className="text-center p-3"
            style={{ backgroundColor: "rgba(0, 0, 0, 0.2)" }}
          >
            © 2020 Copyright:
            <a className="text-white" href="#">
              My ToDosss
            </a>
          </div>
        </footer>
      </section>
    </div>
  );
};

export default Footer;
