import React, { useEffect, useState } from "react";
import "./UpdateTodo.css";
import { useNavigate, useParams } from "react-router";

const UpdateTodo = () => {
  const [title, setTitle] = useState("");
  const [datetime, setDatetime] = useState();
  const [desc, setDesc] = useState("");

  const auth = localStorage.getItem("user");
  const user = JSON.parse(auth);
  const navigate = useNavigate();

  const { id } = useParams();

  const getTodo = async () => {
    let result = await fetch(`http://localhost:8080/todo/${id}`);
    result = await result.json();
    console.log(result);
    setTitle(result.title);
    setDesc(result.desc);
    setDatetime(new Date(result.datetime));
  };
  useEffect(() => {
    console.log("useeffect");
    getTodo();
  }, [id]);
  const updateHandle = async (e) => {
    e.preventDefault();
    let result = await fetch(`http://localhost:8080/todo/${id}`, {
      method: "PUT",
      body: JSON.stringify({ title, datetime, desc }),
      headers: {
        "Content-Type": "application/json",
      },
    });
    result = await result.json();
    if (result) navigate("/list");
  };
  return (
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <p class="h1 text-center mt-3 mb-4 pb-3 text-primary">
          <i class="fas fa-user me-3"></i>
          Hi {user.username}
        </p>
        <div class="col d-flex justify-content-center">
          <div
            class="card"
            id="list1"
            style={{
              borderRadius: ".75rem",
              backgroundColor: "#eff1f2",
              width: "50%",
            }}
          >
            <form onSubmit={updateHandle}>
              <div class="card-body py-4 px-4 px-md-5">
                <input
                  name="title"
                  onChange={(e) => setTitle(e.target.value)}
                  type="text"
                  class="form-control form-control-lg text-center"
                  id="exampleFormControlInput1"
                  placeholder="Todo Title ..."
                  value={title}
                />

                <div class="pb-2">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-flex flex-row align-items-center">
                        <input
                          name="desc"
                          onChange={(e) => {
                            setDesc(e.target.value);
                          }}
                          type="text"
                          class="form-control form-control-lg"
                          id="exampleFormControlInput1"
                          placeholder="Add new..."
                          value={desc}
                        />

                        {/* <button type="button" class="btn btn-primary"></button> */}
                      </div>
                    </div>
                  </div>
                  <input
                    name="datetime"
                    onChange={(e) => {
                      setDatetime(e.target.value);
                    }}
                    type="date"
                    class="form-control form-control-lg"
                    style={{ border: "none", textAlign: "center" }}
                    value={new Date(datetime)}
                  />
                </div>
              </div>
              <button className="" style={{ border: "none" }}>
                <i
                  className="fa fa-plus-circle fa-xl text-primary"
                  aria-hidden="true"
                  style={{
                    fontSize: "3rem",
                    textAlign: "center",
                  }}
                ></i>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateTodo;
