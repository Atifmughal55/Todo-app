import moment from "moment";
import React, { useEffect, useState } from "react";

function generateRandomColor() {
  const colors = [
    "#F2994A",
    "#F2C94C",
    "#56CCF2",
    "#2F80ED",
    "#6FCF97",
    "#00B894",
    "#F3A712",
    "#1D3557",
    "#457B9D",
    "#A8DADC",
    "#F1FAEE",
    "#E63946",
    "#F1D4AF",
    "#4D908E",
    "#F2CC8F",
    "#264653",
    "#2A9D8F",
    "#E9C46A",
    "#277DA1",
    "#F4A261",
    "#E76F51",
    "#6096BA",
    "#FFB6B9",
    "#FFEE93",
    "#91C499",
    "#8D99AE",
    "#D4A5A5",
  ];
  const randomIndex = Math.floor(Math.random() * colors.length);
  return colors[randomIndex];
}
const Complete = () => {
  const [todo, setTodo] = useState([]);

  const auth = localStorage.getItem("user");
  const user = JSON.parse(auth);
  const getTodos = async () => {
    let todos = await fetch(`http://localhost:8080/todocomplete/${user._id}`);
    todos = await todos.json();
    console.log(todos[0]);
    setTodo(todos);
  };
  // console.log(todos);

  const recycle = async (id) => {
    let todos = await fetch(`http://localhost:8080/recycle/${id}`, {
      method: "PUT",
    });
    todos = await todos.json();
    getTodos();
  };

  useEffect(() => {
    getTodos();
  }, []);

  const deleteTodo = async (id) => {
    let res = await fetch(`http://localhost:8080/todo/${id}`, {
      method: "delete",
    });

    res = await res.json();
    if (res) {
      getTodos();
    }
  };
  const currentDate = new Date();

  return (
    <div class="container" style={{ height: "100vh", margin: "60px auto" }}>
      <p class="h1 text-center mt-2 mb-4 text-primary">
        <u>Completed</u>
      </p>
      <div class="row">
        {todo?.map((td, index) => {
          return (
            <>
              <div class="col-lg-4 col-md-6">
                <div
                  class="card card-margin"
                  style={{
                    background: `linear-gradient(135deg, ${generateRandomColor()} 0%, ${generateRandomColor()} 100%)`,
                  }}
                  key={index}
                >
                  <div class="card-header text-center no-border">
                    <h4 class="card-title ">{td.title}</h4>
                    <span style={{ marginLeft: "auto" }}>Complete on</span>
                  </div>
                  <div class="card-body pt-0">
                    <div class="widget-49">
                      <div class="widget-49-title-wrapper">
                        <div class="widget-49-date-primary">
                          <span class="widget-49-date-day">
                            {moment(td.datetime).format("Do")}
                          </span>
                          <span class="widget-49-date-day">
                            {moment(td.datetime).format("MMM")}
                          </span>
                        </div>
                        <div class="widget-49-meeting-info">
                          <span class="widget-49-meeting-time">
                            {moment(td.datetime).format("YYYY")}
                          </span>
                        </div>
                      </div>
                      <ol class="widget-49-meeting-points">
                        <li class="widget-49-meeting-item">
                          <span>{td.desc}</span>
                        </li>
                      </ol>
                      <div class="d-flex justify-content-around text-dark display-6">
                        <i
                          class="fa-solid fa-rotate-left"
                          style={{ cursor: "pointer" }}
                          onClick={() => recycle(td._id)}
                        ></i>
                        <i
                          class="fa-solid fa-trash"
                          style={{ cursor: "pointer" }}
                          onClick={() => deleteTodo(td._id)}
                        ></i>
                        {/* </button> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          );
        })}
      </div>
    </div>
  );
};

export default Complete;
