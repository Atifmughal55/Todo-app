import React, { useState } from "react";
import "./SignUp.css";
import { Link, useNavigate } from "react-router-dom";

const SignUp = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [formErr, setFormErr] = useState({});

  const formValidation = () => {
    let err = {};
    if (username === "") {
      err.username = "username is required";
    }
    if (email === "") {
      err.email = "email is required";
    }
    if (password === "") {
      err.password = "password is required";
    }
    setFormErr({ ...err });
    return Object.keys(err) < 1;
  };
  const handleSubmit = async (e) => {
    // console.log("form submission");
    e.preventDefault();

    let isValid = formValidation();

    if (isValid) {
      let data = await fetch("http://localhost:8080/register", {
        method: "POST",
        body: JSON.stringify({ username, email, password }),
        headers: {
          "content-type": "application/json",
        },
      });
      navigate("/login");
      data = await data.json();
    } else {
      alert("Please fill all the information");
    }
  };

  return (
    <div className="bg-image">
      <div className="container" style={{ height: "100vh" }}>
        <div class="loginBox">
          <img
            class="user"
            src="https://i.ibb.co/yVGxFPR/5.png"
            height="100px"
            width="100px"
            alt=""
          />

          <h3>Register here</h3>
          <form>
            <div class="inputBox">
              <input
                style={{ margin: "0" }}
                id="uname"
                type="text"
                name="Username"
                placeholder="Username"
                onChange={(e) => {
                  setUsername(e.target.value);
                }}
              />
              <p
                style={{
                  color: "red",
                  margin: "0",
                  padding: "0",
                  textAlign: "end ",
                }}
              >
                {formErr.username}
              </p>
              <input
                style={{ margin: "0" }}
                id="pass"
                type="email"
                name="Password"
                placeholder="Email Address"
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
              />
              <p
                style={{
                  color: "red",
                  margin: "0",
                  padding: "0",
                  textAlign: "end ",
                }}
              >
                {formErr.email}
              </p>
              <input
                style={{ margin: "0" }}
                id="pass"
                type="password"
                name="Password"
                placeholder="Password"
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
              />
              <p
                style={{
                  color: "red",
                  margin: "0",
                  padding: "0",
                  textAlign: "end ",
                }}
              >
                {formErr.password}
              </p>
            </div>
            <button
              onClick={handleSubmit}
              className="btn btn-primary"
              style={{ marginTop: "5px" }}
            >
              Register Now
            </button>
          </form>
          <div class="text-center">
            <Link to="/login" style={{ color: "#59238F" }}>
              Login
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
