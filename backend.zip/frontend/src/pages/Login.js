import React, { useState } from "react";
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState({
    uname: "",
    password: "",
  });

  const submitHandler = async (e) => {
    e.preventDefault();
    let data = await fetch(`http://localhost:8080/register/${user.uname}`);
    data = await data.json();
    if (data.username === user.uname) {
      if (data.password === user.password) {
        localStorage.setItem("user", JSON.stringify(data));
        navigate("/");
      } else {
        alert("Password is Incorrrect");
      }
    } else {
      alert("User not found");
    }
  };

  return (
    <div className="container" style={{ height: "100vh" }}>
      <div class="loginBox">
        <img
          class="user"
          src="https://i.ibb.co/yVGxFPR/2.png"
          height="100px"
          width="100px"
          alt=""
        />

        <h3>Login here</h3>
        <form>
          <div class="inputBox">
            <input
              id="uname"
              type="text"
              name="Username"
              placeholder="Username"
              onChange={(e) => setUser({ ...user, uname: e.target.value })}
            />
            <input
              id="pass"
              type="password"
              name="Password"
              placeholder="Password"
              onChange={(e) => setUser({ ...user, password: e.target.value })}
            />
          </div>
          <input onClick={submitHandler} type="submit" name="" value="Login" />
        </form>
        <Link to="">
          Forget Password
          <br />
        </Link>
        <div class="text-center">
          <Link to="/signup" style={{ color: "#59238F" }}>
            Sign-Up
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
