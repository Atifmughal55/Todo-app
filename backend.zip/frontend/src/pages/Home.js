import React, { useEffect, useState } from "react";
import "./Home.css";
import { Link, useNavigate } from "react-router-dom";

const Home = () => {
  const auth = localStorage.getItem("user");
  const user = JSON.parse(auth);
  const navigate = useNavigate();
  // const [todo, setTodo] = useState({
  //   title: "",
  //   datetime: "",
  //   desc: "",
  // });
  const [title, setTitle] = useState("");
  const [datetime, setDatetime] = useState("");
  const [desc, setDesc] = useState("");
  const handleSubmit = async (e) => {
    e.preventDefault();
    //   setTodos([...todos, todo]);
    //   console.log(todos);

    let data = await fetch("http://localhost:8080/todo", {
      method: "POST",
      body: JSON.stringify({ title, datetime, desc, userId: user._id }),
      headers: {
        "content-type": "application/json",
      },
    });
    // data = await data.json();
    navigate("list");
  };
  // const handleChange = (e) => {
  //   // setTodo({ ...todo, [e.target.name]: e.target.value });
  // };

  return (
    <div class="container py-5">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <p class="h1 text-center mt-3 mb-4 pb-3 text-primary">
          <i class="fas fa-user me-3"></i>
          Hi {user.username}
        </p>
        <div class="col d-flex justify-content-center">
          <div
            class="card"
            id="list1"
            style={{
              borderRadius: ".75rem",
              backgroundColor: "#eff1f2",
              width: "50%",
            }}
          >
            <form onSubmit={handleSubmit}>
              <div class="card-body py-4 px-4 px-md-5">
                <input
                  name="title"
                  onChange={(e) => setTitle(e.target.value)}
                  type="text"
                  class="form-control form-control-lg text-center"
                  id="exampleFormControlInput1"
                  placeholder="Todo Title ..."
                />

                <div class="pb-2">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-flex flex-row align-items-center">
                        <input
                          name="desc"
                          onChange={(e) => {
                            setDesc(e.target.value);
                          }}
                          type="text"
                          class="form-control form-control-lg"
                          id="exampleFormControlInput1"
                          placeholder="Add new..."
                        />

                        {/* <button type="button" class="btn btn-primary"></button> */}
                      </div>
                    </div>
                  </div>
                  <input
                    name="datetime"
                    onChange={(e) => {
                      setDatetime(e.target.value);
                    }}
                    // {//from ww  w . j  a  va2s. c  o  m
                    //   var today = new Date().toISOString().split('T')[0];
                    //   document.getElementsByName("setTodaysDate")[0].setAttribute('min', today);
                    // }
                    type="date"
                    class="form-control form-control-lg"
                    style={{ border: "none", textAlign: "center" }}
                  />
                </div>
              </div>
              <button
                type="submit"
                className=""
                style={{
                  border: "none",
                  marginBottom: "6px",
                }}
              >
                <i
                  className="fa fa-plus-circle fa-xl text-primary"
                  aria-hidden="true"
                  style={{
                    fontSize: "3rem",
                    textAlign: "center",
                  }}
                ></i>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
