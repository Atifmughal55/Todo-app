import React, { useEffect } from "react";
import "./Navbar.css";
import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
  const auth = localStorage.getItem("user");
  const navigate = useNavigate();

  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };
  // useEffect(() => {
  //   if (auth) {
  //     navigate("/");
  //   }
  // }, []);
  return (
    <nav className="navbar navbar-expand-lg fixed-top bg-light navbar-light">
      <div className="container">
        <Link className="navbar-brand " to="/">
          <h3
            style={{
              fontFamily: "pacifico",
              background: "-webkit-linear-gradient(#6e5fd1, #d1cf31, #e30f41)",
              webkitBackgroundClip: "text",
              webkitTextFillColor: "transparent",
            }}
          >
            My To-Do
          </h3>
        </Link>
        {/* <button
            className="navbar-toggler"
            type="button"
            data-mdb-toggle="collapse"
            data-mdb-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <i className="fas fa-bars"></i>
          </button> */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          {auth ? (
            <>
              <div className="mx-auto">
                <ul className="navbar-nav ">
                  <li className="nav-item">
                    <Link className="nav-link mx-2 text-primary" to="/">
                      <i className="fas fa-plus-circle pe-2"></i>Add Todo
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link mx-2 text-primary" to="/list">
                      <i className="fas fa-tasks pe-2"></i>Task List
                    </Link>
                  </li>
                  <li className="nav-item ">
                    <Link className="nav-link mx-2 text-primary" to="/complete">
                      <i class="fa fa-check-square p-2" aria-hidden="true"></i>
                      Completed
                    </Link>
                  </li>
                  <li className="nav-item"></li>
                </ul>
              </div>
              <div className="">
                <button onClick={logout} className="btn btn-danger">
                  Log Out
                </button>
              </div>
            </>
          ) : (
            <div></div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
